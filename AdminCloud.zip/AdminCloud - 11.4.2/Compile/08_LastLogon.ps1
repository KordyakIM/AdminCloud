﻿###########################################################
# Разработчик: Кордяк Иван Михайлович kordyakim@gmail.com #
###########################################################
#таблица для выгрузки информации по компьютеру---------------------
#[string]$SCCMNameSpace="root\sms\site_$SiteName"
$ListLogon = New-Object System.Windows.Forms.ListView
$ListLogon.dock = "Fill"
$ListLogon.AutoSize = $true
$ListLogon.View = "Details"
$ListLogon.MultiSelect = $true
$ListLogon.FullRowSelect = $True
$ListLogon.LabelEdit = $True
$ListLogon.AllowColumnReorder = $True
$ListLogon.GridLines = $true
$ListLogon.Columns.Add("LastLogonName").TextAlign = "Center"
$ListLogon.Columns.Add("DisplayName").TextAlign = "Center"
$ListLogon.Columns.Add("E-mail").TextAlign = "Center"
$ListLogon.Columns.Add("LastLogonTime").TextAlign = "Center"
for ($c=0; $c -lt $ListLogon.Columns.Count; $c++){
   $ListLogon.Columns[$c].Width = 164
}
$ListLogon.add_KeyDown({
	param($sender, $e)
	if ($_.KeyCode -eq "C" -and $e.Control){
		Set-ClipBoard_List -Get_list_array $ListLogon
	}
	if ($_.keycode -eq "A" -and $e.Control){
		$ListLogon.Items | %{$_.selected = $true}
	}
})
#Настройка обработчика событий (Set up the event handler)
$ListLogon.add_ColumnClick({
	if ($ListLogon.Items.Count -gt 1){
		SortListTwoview -Column $_.Column -Get_list_array $ListLogon
	}
})
#контекстное меню
$ListLogon.add_ItemSelectionChanged({
	if($ListLogon.SelectedItems -and ($ListLogon.SelectedItems.text -ne "")){
		$Menu_Obtain_LastLogon.Enabled = $true
		if($ListLogon.SelectedItems | where-object { $_.SubItems[2].Text -ne ""}){
			$SendMail.Enabled = $true
		}else{
			$SendMail.Enabled = $false
		}
	}else{
		$Menu_Obtain_LastLogon.Enabled = $false
		$SendMail.Enabled = $false
	}
})
$tabControl_LastLogon_PC.Controls.add($ListLogon)
#------------------------------------------------------------------------------------------------------------------------------
#Начало функции с запросом параметров----------------
function Get-LastLogon {
#    param(
#        $ComputerName = $listPC.Items[$listPC.FocusedItem.Index].Text
#    )
	param (
        [Parameter(Mandatory)]
        [string]$ComputerName
	)
$progressBar.Text = $progressBarStep
$check_connect_SCCM = $false
$not_found_in_SCCM = $false
#начало запроса всей функции------------------------
			#указывает запрос в библиотеку SCCM
			[array]$Array_Lastlogon = @{}
			$Get_WmiObject = Get-WmiObject -namespace $SCCMNameSpace -computer $SCCMServer -query "select SMS_G_System_SYSTEM_CONSOLE_USER.* 
			from SMS_R_System inner join SMS_G_System_SYSTEM_CONSOLE_USER on SMS_G_System_SYSTEM_CONSOLE_USER.ResourceID = SMS_R_System.ResourceId 
			where SMS_R_System.Name = '$ComputerName'" | select SystemConsoleUser,LastConsoleUse
			$Get_WmiObject | % {
				$Object = New-Object PSObject
		        $Object | add-member Noteproperty -Name "LastLogon" -Value $_.SystemConsoleUser -Force
				$Object | add-member Noteproperty -Name "TimeStamp" -Value $_.LastConsoleUse -Force
				$Array_Lastlogon+=$Object 
			}
#$progressBar.Text += $progressBarStep	
$progressBar.Text = $progressBar.Text -replace $progressBarStep_next,$progressBarStep;$progressBar.refresh()
			$Get_WmiObject = Get-WmiObject -namespace $SCCMNameSpace -computer $SCCMServer -query "select SMS_G_System_SYSTEM_CONSOLE_USAGE.* 
			from  SMS_R_System inner join SMS_G_System_SYSTEM_CONSOLE_USAGE on SMS_G_System_SYSTEM_CONSOLE_USAGE.ResourceID = SMS_R_System.ResourceId 
			where SMS_R_System.Name = '$ComputerName'" | select TopConsoleUser,TimeStamp
			$Get_WmiObject | % {
				$Object = New-Object PSObject
		        $Object | add-member Noteproperty -Name "LastLogon" -Value $_.TopConsoleUser -Force
				$Object | add-member Noteproperty -Name "TimeStamp" -Value $_.TimeStamp -Force
				$Array_Lastlogon+=$Object 
			}
#$progressBar.Text += $progressBarStep		
$progressBar.Text = $progressBar.Text -replace $progressBarStep_next,$progressBarStep;$progressBar.refresh()
			$Get_WmiObject = Get-WmiObject -namespace $SCCMNameSpace -computer $SCCMServer -query "SELECT SMS_UserMachineRelationship.*
			FROM SMS_R_System inner JOIN SMS_UserMachineRelationship ON SMS_UserMachineRelationship.ResourceID = SMS_R_System.ResourceID
			WHERE SMS_R_System.Name = '$ComputerName'" | select UniqueUserName,CreationTime
			$Get_WmiObject | % {
				$Object = New-Object PSObject
		        $Object | add-member Noteproperty -Name "LastLogon" -Value $_.UniqueUserName -Force
				$Object | add-member Noteproperty -Name "TimeStamp" -Value $_.CreationTime -Force
				$Array_Lastlogon+=$Object 
			}
			[array]$Array_Lastlogon_unique = @{}
			$Array_Lastlogon_unique = $Array_Lastlogon  |
			Group-Object 'LastLogon' | %{ $_.Group | Sort-Object -Property TimeStamp -Descending | Select 'LastLogon','TimeStamp' -First 1}
			$ListLogon.Items.Clear()
			if($Array_Lastlogon_unique.LastLogon){
				$Array_Lastlogon_unique | % {
#$progressBar.Text += $progressBarStep
$progressBar.Text = $progressBar.Text -replace $progressBarStep_next,$progressBarStep;$progressBar.refresh()
					if($_.LastLogon){
						#convert time
						$TimeStamp = $_.TimeStamp -replace "[.].*",""
						$TimeStamp = $TimeStamp -replace '^(....)(..)(..)(..)(..)(..)$','$1.$2.$3 $4:$5:$6'
						#account
						$SamAccountName = $_.LastLogon -replace ".*\\",""
						$Account = ""
						$Account = Get-ADUser $SamAccountName -Properties * -ErrorAction SilentlyContinue | select EmailAddress,DisplayName
						$item = if($_.LastLogon){New-Object System.Windows.Forms.ListViewItem($_.LastLogon)}else{New-Object System.Windows.Forms.ListViewItem(@{})}
						if($Account.displayname){$item.SubItems.Add($Account.displayname)}else{$item.SubItems.Add(@{})}
						if($Account.EmailAddress){$item.SubItems.Add($Account.EmailAddress)}else{$item.SubItems.Add(@{})}
						if($TimeStamp){$item.SubItems.Add($TimeStamp)}else{$item.SubItems.Add(@{})}
						$ListLogon.Items.AddRange($item)
					}
				}
			}else{
				$not_found_in_SCCM = $true
#				$item = New-Object System.Windows.Forms.ListViewItem($not_found)
#				for( $Num = 1; $ListLogon.Columns.Count -gt $Num; $Num++ ){	
#					$item.SubItems.Add($not_found)
#				}
#				$ListLogon.Items.AddRange($item)
				Get-WmiObject -class SMS_Collection -namespace $SCCMNameSpace -computer $SCCMServer -filter "CollectionID='NN00022E'"
				if($? -eq $false){$check_connect_SCCM = $true}
			}
	#сортирует listview по последнему LastLogon
	if ($ListLogon.Items.Count -gt 1){
		SortListOneview -Column 3 -Get_list_array $ListLogon
	}
	$progressBar.Text = $progressBarEnd
	if($not_found_in_SCCM){$progressBar.Text = $progressBar_comp_not_found_in_SCCM;$progressBar.refresh()}
	if($check_connect_SCCM){$progressBar.Text = $progressBarSCCM;$progressBar.refresh()}
}
##копирует содержимое listview--------------------------------------------
Function send-mail {
	[string]$e_mail= ""
	$ListLogon.SelectedItems | % {if($_.SubItems[2].Text -ne ""){$e_mail += $_.SubItems[2].Text+"; "}}
	$outlook = New-Object -comObject Outlook.Application
	$mail = $outlook.CreateItem(0)
	$mail.To = $e_mail
	$mail.Subject = "AdminCloud"
	$mail.Body = ""
	$inspector = $mail.GetInspector
	$inspector.Activate()
}
##------------------------------------------------------------------------
#контекстное меню вызывается в Listview
$SendMail = New-Object System.Windows.Forms.MenuItem
$SendMail.Text = "Отправить письмо"
$SendMail.Enabled = $false
$SendMail.Add_Click({
	send-mail
})
#contextmenu--------------------------------------------------------------
$Menu_Obtain_LastLogon = New-Object System.Windows.Forms.MenuItem
$Menu_Obtain_LastLogon.Text = "Получить SamAccountName LastLogon"
$Menu_Obtain_LastLogon.Enabled = $false
$Menu_Obtain_LastLogon.Add_Click({
	$textbox0.Text = $ListLogon.Items[$ListLogon.FocusedItem.Index].Text -replace ".*\\",""
	$textBox0.ForeColor = 'WindowText'
	Fill-List_cache
})
$ContextMenuP4 = New-Object System.Windows.Forms.ContextMenu
$ContextMenuP4.MenuItems.AddRange(@($SendMail))
$ContextMenuP4.MenuItems.AddRange(@($Menu_Obtain_LastLogon))
$ListLogon.ContextMenu = $ContextMenuP4
#------------------------------------------------------------------------------------------------------------------------------