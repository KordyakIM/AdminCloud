﻿###################################################
# Разработчик: Кордяк Иван Михайлович @ BANDI-0GA #
###################################################
#SQL input data to connect AppV database
$SQLServer_AppV = "App-V"
$SQLDBName_AppV = "AppVReporting"
$SqlConnection_AppV = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection_AppV.ConnectionString = "Server = $SQLServer_AppV; Database = $SQLDBName_AppV; Integrated Security=True"
$SqlQuery_AppV = "select distinct
        app_name AS 'AppName'
        from dbo.ApplicationUsage
        group by app_name
        order by app_name"
$SqlCmd_AppV = New-Object System.Data.SqlClient.SqlCommand($SqlQuery_AppV,$SqlConnection_AppV)
$SqlAdapter_AppV = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter_AppV.SelectCommand = $SqlCmd_AppV
$DataSet_AppV = New-Object System.Data.DataSet
$SqlAdapter_AppV.Fill($DataSet_AppV)
$AppV_Package_name = $DataSet_AppV.Tables[0].AppName
#таблица для выгрузки AppV---------------------
$List_AppV_Package = New-Object System.Windows.Forms.ListView
$List_AppV_Package.dock = "Fill"
$List_AppV_Package.Height = 200
$List_AppV_Package.AutoSize = $true
$List_AppV_Package.View = "Details"
$List_AppV_Package.MultiSelect = $true
$List_AppV_Package.FullRowSelect = $True
$List_AppV_Package.LabelEdit = $True
$List_AppV_Package.AllowColumnReorder = $True
$List_AppV_Package.GridLines = $true
$List_AppV_Package.Sorting = "Descending" # "Ascending"
$List_AppV_Package.Columns.Add("App Name").TextAlign = "Center"
$List_AppV_Package.Columns.Add("Package Name").TextAlign = "Center"
$List_AppV_Package.Columns.Add("Account").TextAlign = "Center"
$List_AppV_Package.Columns.Add("Name PC").TextAlign = "Center"
$List_AppV_Package.Columns.Add("Version Soft").TextAlign = "Center"
$List_AppV_Package.Columns.Add("Last Used").TextAlign = "Center"
$List_AppV_Package.Columns.Add("Use Count").TextAlign = "Center"
for ($c=0; $c -lt $List_AppV_Package.Columns.Count; $c++){
   $List_AppV_Package.Columns[$c].Width = 94
}
$List_AppV_Package.add_KeyDown({
	param($sender, $e)
	if ($_.KeyCode -eq "C" -and $e.Control){
		Set-ClipBoard_List -Get_list_array $List_AppV_Package
	}
	if ($_.keycode -eq "A" -and $e.Control){
		foreach ($List_AppV_PackageItem in $List_AppV_Package.Items){
		    $List_AppV_PackageItem.selected = $true
		}
	}
})
#Настройка обработчика событий (Set up the event handler)
$List_AppV_Package.add_ColumnClick({
	if ($List_AppV_Package.Items.Count -gt 1){
		SortListTwoview -column $_.Column -Get_list_array $List_AppV_Package
	}
})
#контекстное меню
$List_AppV_Package.add_ItemSelectionChanged({
	if($List_AppV_Package.SelectedItems -and ($List_AppV_Package.SelectedItems.text -ne $not_found)){
		if($List_AppV_Package.SelectedItems | where-object { $_.SubItems[2].Text -ne $not_found}){
			$SendMail.Enabled = $true
		}else{
			$SendMail.Enabled = $false
		}
	}else{
		$SendMail.Enabled = $false
	}
})
$tabControl_AppV_History.Controls.add($List_AppV_Package)

##group for $List_AppV_Package+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
$Group_AppV_comboBox = New-Object System.Windows.Forms.GroupBox
$Group_AppV_comboBox.dock = "top"
$Group_AppV_comboBox.Height = 40
$tabControl_AppV_History.Controls.Add($Group_AppV_comboBox);
#кнопка для выгрузки
$btn_AppV = New-Object System.Windows.Forms.Button;    
$btn_AppV.Dock = "Left"
$btn_AppV.Size = New-Object System.Drawing.Size(180, 25);    
$btn_AppV.Name = "btn0";    
$btn_AppV.Text = "Выгрузить";   
$btn_AppV.Add_Click({
	$progressBar.Text = $progressBarStep;$progressBar.refresh()
	$package_name = $comboBox_AppV.text -replace "'","''"
	$check_connect_AppV = $false #настройки проверки соединения AppV
	$SqlQuery_AppV = "SELECT
                          MAX(ApplicationUsage.end_time) AS 'Last_Used'
                         ,ApplicationUsage.username AS 'Account'
                         ,ClientInformation.host_name AS 'Name_PC'
                         ,ApplicationUsage.app_name AS 'App_Name'
                         ,ApplicationUsage.app_version AS 'Version_Soft'
                         ,PackageInformation.package_name AS 'Package_Name', COUNT(*) as 'Use_Count'
                        FROM dbo.ClientInformation
                        INNER JOIN dbo.ApplicationUsage
                          ON ClientInformation.host_id = ApplicationUsage.host_id
                        INNER JOIN dbo.PackageInformation
                          ON PackageInformation.host_id = ApplicationUsage.host_id
                        where ApplicationUsage.app_name = N'$($package_name)'
                                                and PackageInformation.version_guid=ApplicationUsage.version_guid
                        GROUP BY ApplicationUsage.app_name
                                ,ApplicationUsage.username
                                ,ClientInformation.host_name
                                ,ApplicationUsage.app_version
                                ,PackageInformation.package_name
                        ORDER BY 'Last_Used'"
	$SqlCmd_AppV = New-Object System.Data.SqlClient.SqlCommand($SqlQuery_AppV,$SqlConnection_AppV)
	$SqlAdapter_AppV = New-Object System.Data.SqlClient.SqlDataAdapter
	$SqlAdapter_AppV.SelectCommand = $SqlCmd_AppV
	$DataSet_AppV = New-Object System.Data.DataSet
	$SqlAdapter_AppV.Fill($DataSet_AppV)
	if(!$?){$check_connect_AppV = $true} #проверка подключения к базе AppV
	[array]$AppV_get_Package_list = @{}
	$AppV_get_Package_list = $DataSet_AppV.Tables[0]
	if($AppV_get_Package_list){
		$List_AppV_Package.Items.Clear()
		foreach ($item in $AppV_get_Package_list) {
			#$progressBar.Text += $progressBarStep;$progressBar.refresh()
			$progressBar.Text = $progressBar.Text -replace $progressBarStep_next,$progressBarStep;$progressBar.refresh()
            $I = $List_AppV_Package.Items.Add($item.App_Name)
			$I.SubItems.Add($item.Package_Name)
			$I.SubItems.Add($item.Account)
			$I.SubItems.Add($item.Name_PC)
			$I.SubItems.Add($item.Version_Soft)
			$I.SubItems.Add([string]$item.Last_Used)
			$I.SubItems.Add([string]$item.Use_Count)
   		}
		SortListOneview -column 5 -Get_list_array $List_AppV_Package
		$progressBar.Text = $progressBarEnd +"Найдено: " + $AppV_get_Package_list.count+ " пакет[а/ов]";$progressBar.refresh()
	}else{
		$progressBar.Text = $progressBar_package_not_found_in_AppV;$progressBar.refresh()
	}
	if($check_connect_AppV){$progressBar.Text = $progressBar_AppV;$progressBar.refresh()}
})
$Group_AppV_comboBox.Controls.Add($btn_AppV);
##------------------------------------------------------------------------
#------------------------------------------------------------------------
$comboBox_AppV = New-Object System.Windows.Forms.comboBox  
$comboBox_AppV.dock = "left"
$comboBox_AppV.Width = 300
$comboBox_AppV.DropDownHeight = 300
$comboBox_AppV.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$comboBox_AppV.add_Click({
	$comboBox_AppV.DroppedDown = $true
})
$Group_AppV_comboBox.Controls.Add($comboBox_AppV);
#------------------------------------------------------------------------
ForEach ($Item in $AppV_Package_name) {
  $comboBox_AppV.Items.Add($Item)
}
$comboBox_AppV.SelectedIndex = 0 # Select the first item by default
#------------------------------------------------------------------------
$Label_AppV_chose = New-Object System.Windows.Forms.Label
$Label_AppV_chose.dock = "left"
$Label_AppV_chose.Text = "Выберите тип запроса:"
$Label_AppV_chose.Width = 140
$Group_AppV_comboBox.Controls.Add($Label_AppV_chose)
##------------------------------------------------------------------------

#таблица для выгрузки AppV---------------------
$List_AppV = New-Object System.Windows.Forms.ListView
$List_AppV.dock = "Top"
$List_AppV.Height = 170
$List_AppV.AutoSize = $true
$List_AppV.View = "Details"
$List_AppV.MultiSelect = $true
$List_AppV.FullRowSelect = $True
$List_AppV.LabelEdit = $True
$List_AppV.AllowColumnReorder = $True
$List_AppV.GridLines = $true
$List_AppV.Columns.Add("App Name").TextAlign = "Center"
$List_AppV.Columns.Add("Package Name").TextAlign = "Center"
$List_AppV.Columns.Add("Account").TextAlign = "Center"
$List_AppV.Columns.Add("Name PC").TextAlign = "Center"
$List_AppV.Columns.Add("Last Used").TextAlign = "Center"
for ($c=0; $c -lt $List_AppV.Columns.Count; $c++){
   $List_AppV.Columns[$c].Width = 131
}
$List_AppV.add_KeyDown({
	#копировать объекты
	param($sender, $e)
	if ($_.KeyCode -eq "C" -and $e.Control){
		Set-ClipBoard_List -Get_list_array $List_AppV
	}
	#выделить объекты
	if ($_.keycode -eq "A" -and $e.Control){
		$progressBar.Text = $progressBarStep;$progressBar.refresh()
		foreach ($List_AppVItem in $List_AppV.Items){
			#$progressBar.Text += $progressBarStep;$progressBar.refresh()
			$progressBar.Text = $progressBar.Text -replace $progressBarStep_next,$progressBarStep;$progressBar.refresh()
		    $List_AppVItem.selected = $true
		}
		$progressBar.Text = $progressBarEnd
	}
})
#Настройка обработчика событий (Set up the event handler)
$List_AppV.add_ColumnClick({
	if ($List_AppV.Items.Count -gt 1){
		SortListTwoview -column $_.Column -Get_list_array $List_AppV
	}
})
#контекстное меню
$List_AppV.add_ItemSelectionChanged({
	if($List_AppV.SelectedItems -and ($List_AppV.SelectedItems.text -ne $not_found)){
		if($List_AppV.SelectedItems | where-object { $_.SubItems[2].Text -ne $not_found}){
			$SendMail.Enabled = $true
		}else{
			$SendMail.Enabled = $false
		}
	}else{
		$SendMail.Enabled = $false
	}
})
$tabControl_AppV_History.Controls.add($List_AppV)

function AppV_get_list {
	$progressBar.Text = $progressBarStep;$progressBar.refresh()
	$check_connect_AppV = $false #настройки проверки соединения AppV
	$SqlQuery_AppV = "SELECT
	                    MAX(ApplicationUsage.end_time) AS 'Last_Used'
	                    ,username AS 'Account'
	                    ,host_name AS 'Name_PC'
	                    ,app_name AS 'App_Name'
						,PackageInformation.package_name AS 'Package_Name'
	                    FROM dbo.ClientInformation
	                    INNER JOIN dbo.ApplicationUsage ON ClientInformation.host_id = ApplicationUsage.host_id
						INNER JOIN dbo.PackageInformation ON PackageInformation.host_id = ApplicationUsage.host_id
	                    where username='NPR\$($SamAccountUser_from_AdminCloud)' and PackageInformation.version_guid=ApplicationUsage.version_guid
	                        GROUP BY app_name
	                        ,username
	                        ,host_name
							,PackageInformation.package_name
	                        ORDER BY 'Name_PC'"
	$SqlCmd_AppV = New-Object System.Data.SqlClient.SqlCommand($SqlQuery_AppV,$SqlConnection_AppV)
	$SqlAdapter_AppV = New-Object System.Data.SqlClient.SqlDataAdapter
	$SqlAdapter_AppV.SelectCommand = $SqlCmd_AppV
	$DataSet_AppV = New-Object System.Data.DataSet
	$SqlAdapter_AppV.Fill($DataSet_AppV)
	if(!$?){$check_connect_AppV = $true} #проверка подключения к базе AppV
	[array]$AppV_get_list = @{}
	$AppV_get_list = $DataSet_AppV.Tables[0]
	$List_AppV.Items.Clear()
	if($AppV_get_list -ne 0){
		foreach ($item in $AppV_get_list) {
			$progressBar.Text = $progressBar.Text -replace $progressBarStep_next,$progressBarStep;$progressBar.refresh()
            $I = $List_AppV.Items.Add($item.App_Name)
			$I.SubItems.Add($item.package_name)
			$I.SubItems.Add($item.Account)
			$I.SubItems.Add($item.Name_PC)
			$I.SubItems.Add([string]$item.Last_Used)
   		}
		SortListOneview -column 4 -Get_list_array $List_AppV
		$progressBar.Text = $progressBarEnd+"Найдено: " + $AppV_get_list.count+ " пакет[а/ов]";$progressBar.refresh()
	}else{
		$progressBar.Text = $progressBar_user_not_found_in_AppV;$progressBar.refresh()
	}
	if($check_connect_AppV){$progressBar.Text = $progressBar_AppV;$progressBar.refresh()}
}